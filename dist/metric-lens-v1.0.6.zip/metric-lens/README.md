# MetricLens 指标速查

在 GA4 / AppsFlyer / Meta 广告后台等**任意网页上划词**，即时看到这个指标是什么意思、公式怎么算、哪里容易搞混。

![icon](icon-preview.png)

---

仓库：https://github.com/everydayplus1/metric-lens

## 安装（约 1 分钟）

1. 从 [dist/](dist/) 下载最新的 `metric-lens-v*.zip` 并解压，得到一个 `metric-lens` 文件夹
2. Chrome 地址栏打开 `chrome://extensions`
3. 打开右上角的 **开发者模式**
4. 点 **加载已解压的扩展程序**，选中刚才解压出来的 `metric-lens` 文件夹
5. 建议点一下工具栏的拼图图标，把 MetricLens **固定**出来

> Chrome 会时不时提示"停用开发者模式扩展程序"，点忽略即可，不影响使用。
> 如果嫌烦，可以走 Chrome 商店 unlisted 上架（见文末）。

## 怎么用

| 操作 | 效果 |
|---|---|
| 选中 `eCPM` | 弹出卡片：一句话定义 + 公式 + 相关词 |
| 选中一整句话 | 列出句子里出现的**所有**已收录指标，点任意一条看详情 |
| 点卡片里的「相关」标签 | 跳到那个词条，可以一路点下去 |
| 点「展开全文」 | 看完整词条（解决什么问题 / 例子 / 易混淆点） |
| 点浏览器工具栏图标 | 搜索框 + 按领域浏览全部词条 |
| `Esc` 或点卡片外 | 关闭 |

**选中的文字没命中词库时，什么都不会弹** —— 不会打扰正常的复制粘贴。

面板底部有两个开关：

- **划词即查** —— 总开关，关掉后完全不响应选区
- **自动高亮页面名词**（默认关）—— 打开后会给页面上已收录的名词加虚线下划线，鼠标点一下出卡片。报表页面开这个会有点花，按需使用。

## 隐私说明

这个扩展需要"读取您在所有网站上的数据"权限，因为**划词功能必须能读到你选中的那段文字**。除此之外：

- **不采集、不上报任何页面内容**，选中的文字只在你自己的浏览器内存里查词典
- **没有任何统计、埋点、第三方 SDK**
- 唯一可能发起的网络请求，是从 GitHub 拉取词条数据文件 `terms.json`。当前版本 `REMOTE_URL` 为空，**完全不联网**
- 全部代码是未压缩、未混淆的明文 JS，加起来不到 900 行，可以自己翻一遍：
  - `content.js` —— 划词和卡片
  - `lib/dict.js` —— 查词匹配
  - `lib/md.js` —— Markdown 渲染
  - `background.js` —— 词库更新
  - `popup.js` —— 面板

## 词库

当前 **33 条词条**，覆盖五个领域：

- **买量与成本** —— CPM、CVR、CPI、CPA、CAC、ROAS、ROAS0/ROAS1、Cohort
- **变现与用户价值** —— eCPM、DAU、ARPU、ARPDAU、ARPPU、IPU、LTV、LT30/LT180
- **投放与出价** —— Campaign、WtoA/AtoA、AEO/VO、ABO/CBO
- **素材与创意** —— Hook rate、Thruplay、CTR、CPC、IPM
- **数据分析与归因** —— Firebase、GA4、AppsFlyer

匹配分三层：

1. **别名** —— `ECPM`/`千次展示收益`、`AppFlyer`（少个 s）、`compaign` 这类误拼都能查到
2. **模式规则** —— 带数字时间窗的写法**不枚举**：`ROAS28`、`ROAS D45`、`LTV(D14)`、`LT90`
   任意天数都认得。这种情况下卡片**标题显示你选中的那个词**（比如 `ROAS4`），
   并在顶部直接给出「ROAS4 = 截止第 4 天的累计收入 ÷ 广告花费」——
   否则标题写着词条名 `ROAS0 / ROAS1`，看起来像识别错了
3. **数字兜底** —— 剥掉尾部数字再试一次，`CPM2024` 也能落到 CPM 上

规则写在 `aliases.json` 的 `_patterns` 里，key 写错或词条改名会让规则静默失效，
所以 `build.py` 会校验并中止构建。

## 词库怎么更新

**已经配好自动更新了，装完就不用管。**

词条来源是一个 Markdown 知识库，`build.py` 把它编译成 `terms.json` 推到本仓库；
每个人的插件每 6 小时拉一次，面板里也能随时手动点「检查更新」。
**加了新词条不需要重装扩展，更不需要重新发 zip 给同学。**

```
知识库 *.md  ──build.py──>  data/terms.json  ──git push──>  GitHub raw
                                                                 │
                                              每 6 小时 / 手动 ←──┘
                                                                 ▼
                                                        所有人的插件
```

维护者更新词库只需要一条命令：

```bash
./sync.sh          # 构建 -> 提交 -> 推送，并打印新的词条数
```

几个设计细节：

- **判据是构建日期不是版本号**。词库随时在长，版本号不会每次都改，
  拿版本号当唯一判据会让新词条永远同步不过来。
- **远程条数骤减时不覆盖本地**（低于本地一半就跳过），防止数据出问题时把大家的词库清空。
- **拉取失败自动沿用内置词库**，不会白屏，离线也能正常用。
- 扩展**本体**（代码）的更新仍需重新加载解压包 —— 除非走 Chrome 商店上架（见文末）。

## 想加词条？

在知识库 md 里按这个格式写一段，重跑 `build.py` 就行：

```markdown
## 名词 — 一句话副标题

**一句话**：最短的定义。

**解决什么问题**：……

**例子**：……

**易混淆**：……

**相关**：[[其他词条]]
```

- 第一个不超过 8 行的代码块会被当成**公式**显示在卡片上
- 缩写、中文名、常见误拼写进 `aliases.json`。**只写「同一个概念的不同写法」** ——
  相关但不同的概念（IPM 之于 CVR、ARPPU 之于 ARPU、Adjust 之于 AppsFlyer）必须各自建词条，
  否则选中它会弹出另一个词的卡片。`build.py` 有两道防呆检查会拦住这种错
- 涉及内部数据的段落前加一行 `<!-- private -->`，**构建时会自动剔除，不会进入公开数据**（`build.py` 还会扫描项目代号做兜底，命中就直接中止构建）

## 上架 Chrome 商店（可选）

开发者模式加载的扩展每次开浏览器都会被提示。如果要给组里长期用，可以：

1. 交一次性 $5 注册开发者账号
2. 上传 zip，**可见性选 Unlisted（不公开）** —— 不会出现在商店搜索里，只有拿到链接的人能装
3. 审核通过后，同学点链接一键安装，且扩展本体也能自动更新

## 目录结构

```
metric-lens/
├── build.py            知识库 md → terms.json
├── aliases.json        手工维护的别名表
├── make_icons.py       生成图标
├── package.sh          打包 zip
├── data/terms.json     构建产物（将来 push 到 public 仓给大家自动更新）
├── extension/          ← 加载到 Chrome 的就是这个目录
│   ├── manifest.json
│   ├── content.js      划词与卡片
│   ├── background.js   词库同步
│   ├── popup.html/js/css
│   ├── lib/dict.js     查词匹配
│   ├── lib/md.js       Markdown 渲染
│   └── data/terms.json 内置词库（离线兜底）
└── test/               单元测试与本地 demo 页
```

## 测试

```bash
JSC=/System/Library/Frameworks/JavaScriptCore.framework/Versions/A/Helpers/jsc

# 词典匹配与 Markdown 渲染
"$JSC" test/fixture.js extension/lib/dict.js extension/lib/md.js test/test_dict.js

# 词库同步判据
"$JSC" test/chrome-shim.js extension/background.js test/test_sync.js
```

覆盖大小写/中文别名/误拼、词边界（`CPIA` 不会误报成 `CPI`）、长别名优先（`LT30` 不被 `LT` 抢）、
Markdown 表格与转义、别名不得指向相关但不同的概念，以及全部词条整篇渲染不报错。
同步判据单独测，因为它错了不会报错、只会让所有人静默收不到更新。
